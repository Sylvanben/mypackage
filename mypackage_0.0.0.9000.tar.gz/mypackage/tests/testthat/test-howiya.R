test_that("multiplication works", {
  expect_null(suppressMessages(howiya()))
})
