library(testthat)
library(mypackage)

test_check("mypackage")
